#!/bin/bash
./runtime/lin/bin/java -jar AdolfFront.jar
